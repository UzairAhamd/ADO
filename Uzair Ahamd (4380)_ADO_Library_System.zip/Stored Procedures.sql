use SQL_Assignment1 
-------------------------Task0_Get_ALL_BOOKS
Go
CREATE PROCEDURE sp_GetBooks
AS
BEGIN
	select * from books 
END
Go

-------------------------Task0_Get_ALL_Users
Go
CREATE PROCEDURE sp_GetUsers
AS
BEGIN
	select * from users
END
GO

--------------------------Task1 Insert book
Go
CREATE PROCEDURE sp_InsertBook
       @Bookname varchar(255),
       @Category varchar(255),
       @Price float(5),
       @ShelfNumber int,
	   @IssuedStatus varchar(255)
AS
BEGIN
       INSERT INTO books
              (Bookname, Category, Price, ShelfNumber,IssuedStatus)
       VALUES
              (@Bookname, @Category, @Price, @ShelfNumber,@IssuedStatus)
END
Go


----------------------------Task2 Insert user
Go
CREATE PROCEDURE sp_InsertUser
       @UserName varchar(255),
	   @CountryID int
AS
BEGIN
       INSERT INTO users(UserName,CountryID) VALUES(@UserName,@CountryID)
END
Go

-----------------------------Task3 get a book's details
Go
CREATE PROCEDURE sp_GetBook
       @Bookname varchar(255)
AS
BEGIN
	select * from books where Bookname= @Bookname
END
Go


------------------------------Task4 get a user's details
Go
CREATE PROCEDURE sp_GetUser
       @UserId int
AS
BEGIN
	select UserID,Username,BookName from users,books where users.UserID= @UserId and books.IssuedTo= @UserId
END
Go
-------------------------------Task5 update a book
Go
CREATE PROCEDURE sp_UpdateBook
	@BookId int,
	@Bookname varchar(255),
	@Category varchar(255),
	@Price float(5),
	@ShelfNumber int,
	@IssuedStatus varchar(255)
AS
BEGIN
	update books set 
		BookName=@BookName,
		Category=@Category,
		Price=@Price,
		ShelfNumber=@ShelfNumber,
		IssuedStatus=@IssuedStatus
		where BookId=@BookId;
END
GO

-------------------------------Task6 update a user
Go
CREATE PROCEDURE sp_UpdateUser
	@UserId int,
	@Username varchar(255),
	@CountryID int
AS
BEGIN
	update users set 
		Username=@Username,
		CountryID=@CountryID
		where UserId=@UserId;
END
GO

----------------------------------Task7 issue book to user
Go
CREATE PROCEDURE sp_IssueBook
	@UserId int,
	@Bookname varchar(255)
AS
BEGIN
	Declare @varUser int
	select @varUser=IssuedTo from books where Bookname=@Bookname
	if (@varUser is null)
	begin
		update books set 
		IssuedTo=@UserId,
		IssuedDate= cast(getdate() as date),
		IssuedStatus='Not Available'
		where BookName=@BookName
		
		return 1
	end
	else
	begin
		return 0
	end
END
Go

-------------------------------Task8 remove a book from table
GO
CREATE PROCEDURE sp_RemoveBook
	@Bookname varchar(255)
AS
BEGIN
	delete from books where Bookname=@Bookname	
END
Go
exec sp_RemoveBook 'Book20'
exec sp_GetBooks
------------------------------Task9 Remove a user form table check for issued books before
Go
CREATE PROCEDURE sp_RemoveUser
	@UserId int
AS
BEGIN
	Declare @varUser int
	declare @r varchar(100)
	select @varUser=IssuedTo from books where IssuedTo=@UserId
	if (@varUser is null)
	begin
		delete from users where UserID=@UserId
	end
END
Go

------------------------------------Task10 Get all books issued by a user
Go
CREATE PROCEDURE sp_UserBooks
	@UserId int
AS
BEGIN
		SELECT Bookname from books where IssuedTo=@UserId
END
Go
exec sp_UserBooks 5
------------------------------------------