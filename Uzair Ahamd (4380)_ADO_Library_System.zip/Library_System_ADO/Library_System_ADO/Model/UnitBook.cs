﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library_System_ADO.Model
{
    public class UnitBook
    {
        public int BookID { get; set; }
        public string BookName { get; set; }
        public string Category { get; set; }
        public double Price { get; set; }
        public int ShelfNumber { get; set; }
        public string IssuedStatus { get; set; }
        public int IssuedTo { get; set; }
        public DateTime IssuedDate { get; set; }
    }
}
