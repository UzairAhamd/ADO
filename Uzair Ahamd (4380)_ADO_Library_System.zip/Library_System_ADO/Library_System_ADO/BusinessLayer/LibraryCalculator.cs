﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Library_System_ADO.DataLayer;
using Library_System_ADO.Model;

namespace Library_System_ADO.BusinessLayer
{
    public class LibraryCalculator : ILibraryCalculator
    {
        //DAL to BAL Dependency Injection for Books
        ISQLDataHelper _sqlDataHelper;
        public LibraryCalculator(ISQLDataHelper sqlDataHelper)
        {
            this._sqlDataHelper = sqlDataHelper;
        }
        //Task0 get books from DAL and return to controller
        public List<UnitBook> GetBooksData()
        {
            return this._sqlDataHelper.GetBooksData();
        }
        //Task0 get users from DAL and return to controller
        public List<UnitUser> GetUsersData()
        {
            return this._sqlDataHelper.GetUsersData();
        }
        //Task1 insert book from controller to db using DAL
        public string InsertBooksData(UnitBook insertBookData)
        {
            return this._sqlDataHelper.AddBookData(insertBookData);    
        }
        //Task2 insert user from controller to db using DAL
        public string InsertUsersData(UnitUser insertUserData)
        {
            return this._sqlDataHelper.AddUserData(insertUserData);
        }
        //Task3 get book information from db
        public UnitBook GetBook(string bookname)
        {
            return this._sqlDataHelper.GetBookData(bookname);
        }
        //Task4 get user infromation from database
        public Tuple<int, string, List<string>> GetUser(int userID)
        {
            return this._sqlDataHelper.GetUserData(userID);
        }
        //Task5 update book record
        public string UpdateBook(int BookID, UnitBook unitBOOK)
        {
            return this._sqlDataHelper.UpdateBookData(BookID,unitBOOK);
        }
        //Task6 update user record
        public string UpdateUser(int UserID, UnitUser unitUSER)
        {
            return this._sqlDataHelper.UpdateUserData(UserID, unitUSER);
        }
        //Task7 issue book to user if book isn't issued already
        public string IssueBook(int UserID, string bookname)
        {
            return this._sqlDataHelper.IssueBookData(UserID, bookname);
        }
        //Task8 remove a book from database
        public string RemoveBook(string bookname)
        {
            return this._sqlDataHelper.RemoveBookData(bookname);
        }
        //Task9 remove a user from database only if user returned all books
        public string RemoveUser(int userID)
        {
            return this._sqlDataHelper.RemoveUserData(userID);
        }
        //Task10 get all books issued by particular user
        public List<string> GetUserBooks(int userID)
        {
            return this._sqlDataHelper.GetUserBooksData(userID);
        }
        //Task11 calculate penalty over user for late book return
        public double CalculatePenalty(string bookName)
        {
            double penalty = 0f;
            double penaltyPerDaypenalty = 1;
            //get book details using stored procedure
            UnitBook bookDetails= this._sqlDataHelper.GetBookData(bookName);
            //create a hardcoded list of special days i.e. october 10 and november 11 for year 2022
            List<DateTime> holidays = new List<DateTime>() { Convert.ToDateTime("11/11/2022"), Convert.ToDateTime("10/10/2022") };
            //create a weekend list code i.e 0 and 1 for saturday and sunday
            List<int> weekend = new List<int>() { 0, 1 };
            //check the status of the book and calculate the business days if book was issued earlier
            if (bookDetails.IssuedStatus.ToLower() == "not available")
            {
                //call function to calculate business days given the issued date, weeekends and holidays
                int businessDays = CalCulateBusinessDays(bookDetails.IssuedDate,holidays, weekend);
                //calculate the penalty if book return days are more than 15
                if (businessDays > 15)
                {
                    penalty = (businessDays-15) * penaltyPerDaypenalty;
                }
                
            }
                return penalty;
        }
        //calculate the business days between the check-out and check-in dates 
        private int CalCulateBusinessDays(DateTime issueDate,List<DateTime> holidays,List<int> weekend)
        {
            int businessDays = 0;
            //compare the issued date with the current(book return date) and increment one for loop
            for (DateTime currentDate = issueDate; currentDate <= DateTime.Now.Date; currentDate = currentDate.AddDays(1))
            {
                int currentDayOfWeek = Convert.ToInt32(currentDate.DayOfWeek);
                //count a date as business if it doesn't fall in weekends and holidays
                if (!(weekend.Contains(currentDayOfWeek) || holidays.Contains(currentDate)))
                {
                    businessDays++;
                }
            }
            return businessDays;
        }
    }
}
