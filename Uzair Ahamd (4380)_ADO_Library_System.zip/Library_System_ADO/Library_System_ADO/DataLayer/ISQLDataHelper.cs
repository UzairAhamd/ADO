﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Library_System_ADO.Model;
namespace Library_System_ADO.BusinessLayer
{
    public interface ISQLDataHelper
    {
        List<UnitBook> GetBooksData();  //get books
        public string AddBookData(UnitBook unitBook);   //insert book
        List<UnitUser> GetUsersData();  //get users
        public string AddUserData(UnitUser unitUser);   //add user
        public UnitBook GetBookData(string bookname);   //get book
        public Tuple<int, string, List<string>> GetUserData(int userID); //get user
        public string UpdateBookData(int BookID, UnitBook unitBOOK);    //update book
        public string UpdateUserData(int UserID, UnitUser unitUSER);    //update user
        public string IssueBookData(int UserID, string bookname);   //issue book
        public string RemoveBookData(string bookname);  //remove book
        public string RemoveUserData(int userID);   //remove user
        public List<string> GetUserBooksData(int userID);   //get user's issued books
    }
}
