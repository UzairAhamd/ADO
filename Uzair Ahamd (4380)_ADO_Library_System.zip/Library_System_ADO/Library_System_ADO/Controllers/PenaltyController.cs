﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Library_System_ADO.BusinessLayer;
using Library_System_ADO.DataLayer;
using Library_System_ADO.Model;

namespace Library_System_ADO.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PenaltyController : Controller
    {
        //BAL to Controller Dependency Injection for Books
        ILibraryCalculator _libraryCalculator;
        public PenaltyController(ILibraryCalculator penaltyCalculator)
        {
            _libraryCalculator = penaltyCalculator;
        }
        //Task0 get all books given the books prompt
        [HttpGet]
        [Route("books")]
        public IEnumerable<UnitBook> GetBooks()
        {
            return _libraryCalculator.GetBooksData();
        }
        //Task0 get all users given the users prompt
        [Route("users")]
        public IEnumerable<UnitUser> GetUsers()
        {
            return _libraryCalculator.GetUsersData();
        }
        //Task3 get detail of a book given the book name
        [Route("book/{bookname}")]
        public UnitBook GetSingleBook(string bookname)
        {
            return _libraryCalculator.GetBook(bookname);
        }
        //Task4 get a user's data given the user' id
        [Route("user/{userID}")]
        public Tuple<int, string, List<string>> GetSingleUser(int userID)
        {
            return _libraryCalculator.GetUser(userID);
        }
        //Task10 get all books issued by a user given the user's id
        [Route("userBooks/{userID}")]
        public List<string> GetSingleUserBooks(int userID)
        {
            return _libraryCalculator.GetUserBooks(userID);
        }
        //Task11 Calculate penalty given the bookname
        [Route("CalculatePenalty/{BookName}")]
        public string ClaculatePenalty(string bookName)
        {
            return "Penalty is "+Convert.ToString(_libraryCalculator.CalculatePenalty(bookName))+" Rupees!";
        }

        [HttpPost]
        [Route("postBook")]
        //Task1 Add a new book to the current books list
        public string AddNewBook([FromBody] UnitBook addNewBook)
        {
            return _libraryCalculator.InsertBooksData(addNewBook);
        }
        //Task2 Add a new user to the current users list
        [Route("postUser")]
        public string AddNewUser([FromBody] UnitUser addNewUser)
        {
            return _libraryCalculator.InsertUsersData(addNewUser);
        }
        [HttpPut]
        //Task5 update the book record given the book's id and book's new data
        [Route("putBook/{BookID}")]
        public string UpdateSingleBook(int BookID, [FromBody] UnitBook unitBOOK)
        {
            return _libraryCalculator.UpdateBook(BookID, unitBOOK);
        }
        //Task6 update the user record given the user's id and user's new data
        [Route("putUser/{UserID}")]
        public string UpdateSingleUser(int UserID, [FromBody] UnitUser unitUSER)
        {
            return _libraryCalculator.UpdateUser(UserID, unitUSER);
        }
        //Task7 issue book given the user id and book name
        [Route("issueBook/{userID}")]
        public string IssueSingleBook(int userID, [FromBody] string bookname)
        {
            return _libraryCalculator.IssueBook(userID, bookname);
        }
        [HttpDelete]
        //Task8 remove the book given the book name
        [Route("delBook/{Bookname}")]
        public string RemoveSingleBook(string bookname)
        {
            return _libraryCalculator.RemoveBook(bookname);
        }
        //Task9 remove the user given the user id
        [Route("delUser/{UserID}")]
        public string RemoveSingleUser(int userID)
        {
            return _libraryCalculator.RemoveUser(userID);
        }
    }
}
