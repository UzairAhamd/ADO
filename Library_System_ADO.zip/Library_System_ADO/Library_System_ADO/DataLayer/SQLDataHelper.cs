﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Library_System_ADO.BusinessLayer;
using Microsoft.Extensions.Configuration;
using Library_System_ADO.Model;

namespace Library_System_ADO.DataLayer
{
    public class SQLDataHelper : ISQLDataHelper
    {
        string connectionString = "";
        public SQLDataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("ProjectDB");
        }
        public List<UnitBook> GetBooksData()
        {
            List<UnitBook> lstBook = new List<UnitBook>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("GetBooks", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    UnitBook Book_Obj = new UnitBook();

                    Book_Obj.BookID = Convert.ToInt32(sdr["BookID"]);
                    Book_Obj.BookName = sdr["Bookname"].ToString();
                    Book_Obj.Category = sdr["Category"].ToString();
                    Book_Obj.Price = Convert.ToDouble(sdr["Price"].ToString());
                    Book_Obj.ShelfNumber = Convert.ToInt32(sdr["ShelfNumber"]);
                    lstBook.Add(Book_Obj);
                }
                con.Close();
            }
            return lstBook;
        }
        public List<UnitBook> AddBookData(UnitBook unitBook)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("InsertBook", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                cmd.CommandText = "Execute InsertBook @Bookname, @Category, @Price, @ShelfNumber";

                cmd.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = textBox1.Text.ToString();
                cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 50).Value = textBox2.Text.ToString();
                cmd.Parameters.Add("@type", SqlDbType.VarChar, 10).Value = comboBox1.Text.ToString();

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                con.Close();
            }
            return lstBook;
        }
        //public List<SpecialDay> GetSpecialDaysData()
        //{
        //    List<SpecialDay> lstSpecialDay = new List<SpecialDay>();

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand("sp_GetCountriesSpecialDays", con);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        con.Open();
        //        SqlDataReader sdr = cmd.ExecuteReader();

        //        while (sdr.Read())
        //        {
        //            SpecialDay specialDay = new SpecialDay();

        //            specialDay.Id = Convert.ToInt32(sdr["Id"]);
        //            specialDay.CountryId = Convert.ToInt32(sdr["CountryId"].ToString());
        //            specialDay.SpecialDate = Convert.ToDateTime(sdr["SpecialDate"].ToString());
        //            lstSpecialDay.Add(specialDay);
        //        }
        //        con.Close();
        //    }
        //    return lstSpecialDay;
        //}
    }
}
