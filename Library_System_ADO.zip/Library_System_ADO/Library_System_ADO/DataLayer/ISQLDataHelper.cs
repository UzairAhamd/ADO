﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Library_System_ADO.Model;
namespace Library_System_ADO.BusinessLayer
{
    public interface ISQLDataHelper
    {
        public List<UnitBook> GetBooksData();
        //public List<SpecialDay> GetSpecialDaysData();
    }
}
