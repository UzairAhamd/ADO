﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Library_System_ADO.BusinessLayer;
using Library_System_ADO.DataLayer;
using Library_System_ADO.Model;

namespace Library_System_ADO.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PenaltyController : Controller
    {
        ILibraryCalculator _libraryCalculator;
        public PenaltyController(ILibraryCalculator penaltyCalculator)
        {
            _libraryCalculator = penaltyCalculator;
        }
        //(Task 1) Add a new book to the current user list
        [HttpPost]
        [Route("postBook")]
        public List<UnitBook> AddNewBook([FromBody] UnitBook addNewBook)

        {
            return _libraryCalculator.InsertBooksData(addNewBook);
        }
        [HttpGet]
        public IEnumerable<UnitBook> GetBooks()
        {
            return _libraryCalculator.GetBooksData();
        }
        //[HttpGet("getspecialdays")]
        //public IEnumerable<SpecialDay> GetSpecialDaysData()
        //{
        //    return _penaltyCalculator.GetSpecialDaysData();
        //}
        //[HttpPost("calculateamount")]
        //public string CalculateAmount(CheckInInput checkInInput)
        //{
        //    return _penaltyCalculator.CalculateAmount(checkInInput);
        //}
    }
}
