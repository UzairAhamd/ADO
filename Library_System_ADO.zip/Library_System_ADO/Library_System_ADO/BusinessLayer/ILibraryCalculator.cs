﻿using System;
using Library_System_ADO.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library_System_ADO.BusinessLayer
{
    public interface ILibraryCalculator
    {
        public List<UnitBook> GetBooksData();
        public List<UnitBook> InsertBooksData(UnitBook addNewBook);
        //public List<SpecialDay> GetSpecialDaysData();
        //public string CalculateAmount(CheckInInput model);
        //public int CalculateAmount(DateTime BookCheckIn, DateTime BookReceived, List<SpecialDay> specialDays, string offDay1, string offDay2);
    }
}
