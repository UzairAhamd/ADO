﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Library_System_ADO.DataLayer;
using Library_System_ADO.Model;

namespace Library_System_ADO.BusinessLayer
{
    public class LibraryCalculator : ILibraryCalculator
    {
        ISQLDataHelper _sqlDataHelper;
        public LibraryCalculator(ISQLDataHelper sqlDataHelper)
        {
            this._sqlDataHelper = sqlDataHelper;
        }
        public List<UnitBook> GetBooksData()
        {
            return this._sqlDataHelper.GetBooksData();
        }
        public List<UnitBook> InsertBooksData(UnitBook insertBookData)
        {
            _sqlDataHelper.Add(insertBookData);
            return libraryStats;
        }
        //public List<SpecialDay> GetSpecialDaysData()
        //{
        //    return this._sqlDataHelper.GetSpecialDaysData();
        //}
        //public string CalculateAmount(CheckInInput model)
        //{
        //    var country = GetCountriesData().FirstOrDefault(p => p.Id == model.CountryId);
        //    List<SpecialDay> specialDays = GetSpecialDaysData().Where(p => p.CountryId == model.CountryId).ToList();
        //    int penaltyAmount = CalculateAmount(model.BookCheckIn, model.BookReceived, specialDays, country.OffDay1, country.OffDay2);
        //    return "Penalty Amount =" + penaltyAmount + country.CurrencyCode;
        //}
        //public int CalculateAmount(DateTime BookCheckIn, DateTime BookReceived, List<SpecialDay> specialDays, string offDay1, string offDay2)
        //{
        //    int amount = 0;
        //    //calculations here
        //    return amount;
        //}
    }
}
